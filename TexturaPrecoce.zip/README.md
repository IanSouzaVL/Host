# Arma Caraio — OptiFine CIT (Minecraft 1.12.2)

Este resource pack usa **Custom Item Textures (CIT)** do OptiFine. Ele precisa
estar instalado no cliente; o servidor pode continuar usando somente o plugin
CrackShot.

## Versões usadas

- Minecraft: `1.12.2`
- Forge: `14.23.5.2859`
- OptiFine: `OptiFine 1.12.2 HD U E3`
  ([download](https://optifine.net/adloadx?f=OptiFine_1.12.2_HD_U_E3.jar&x=))

O Forge é o carregador de mods do cliente. Instale o OptiFine nessa instância
do Forge para que as texturas por nome funcionem.

## Uso

1. Instale uma versão do **OptiFine para Minecraft 1.12.2**.
2. Ative este resource pack.
3. Em **Opções → Configurações de vídeo → Qualidade**, deixe **Itens
   personalizados / Custom Items** em `ON`.
4. Use o item entregue e já renomeado pelo servidor. A Espada Especial é um
   graveto com Knockback.
   Maiúsculas/minúsculas não importam e o itálico normal da bigorna é aceito.

| Nome na bigorna | Textura |
| --- | --- |
| `Desert Eagle` | pistola Desert Eagle |
| `Rifle de Diamante` | rifle marrom |
| `Revolver Dourado` | revólver |
| `Rifle de Ferro` | rifle com mira |
| `Rifle de Pedra` | fuzil |
| `Espada Especial` | espada |

Uma enxada de diamante com outro nome (ou sem nome) permanece com a textura
vanilla. Um graveto com outro nome (ou sem nome) também permanece vanilla.

## Estrutura e documentação CIT

No OptiFine para 1.12.2, as regras CIT deste pack ficam em:

```text
assets/minecraft/mcpatcher/cit/
```

Cada arquivo `.properties` contém o item-base, o nome a ser reconhecido e a
textura correspondente. As imagens usadas pelas regras estão em:

```text
assets/minecraft/mcpatcher/cit/textures/
```

A referência oficial da sintaxe CIT está na
[documentação do OptiFine](https://github.com/sp614x/optifine/blob/master/OptiFineDoc/doc/cit_single.properties).

## CrackShot

Para a Desert Eagle, o CrackShot usa `Item_Type: 293` (`DIAMOND_HOE`) e
`Item_Name: "&eDesert Eagle"`. O OptiFine reconhece essa combinação e troca
somente a aparência no cliente.
